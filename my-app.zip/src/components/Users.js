import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Users = () => {
  const [posts, setPosts] = useState([]);
  const [activeFolder, setActiveFolder] = useState('users');
  const [users, setUsers] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [userProfileVisible, setUserProfileVisible] = useState(false);
  const [userProfileImage, setUserProfileImage] = useState('/icons/default-avatar.png');
  const [userData, setUserData] = useState(null);
  const [originalPosts, setOriginalPosts] = useState([]);
  const [newUser, setNewUser] = useState({
    fullName: '',
    email: '',
    login: '',
    password: '',
    passwordConfirmation: '',
    role: 'USER',
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);

  const navigate = useNavigate();

  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  const role = localStorage.getItem('role');
  const searchRef = useRef(null);

  useEffect(() => {
    if (token) {
      fetchUsers();
      fetchUserProfile();
    } else {
      setIsLoggedIn(false);
    }
  }, [token]);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('/api/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(response.data);
      setFilteredUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUserProfileImage(response.data.profilePicture || '/icons/default-avatar.png');
      setUserData(response.data);
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout', {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      localStorage.clear();

      setIsLoggedIn(false);

      navigate('/SignIn');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      await axios.patch(
        `/api/users/${userId}`,
        { role: newRole },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchUsers();
    } catch (error) {
      console.error('Error updating user role:', error);
    }
  };

  const handleUserDelete = async (userId) => {
    try {
      await axios.delete(`/api/users/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchUsers();
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleAddUserChange = (e) => {
    setNewUser({ ...newUser, [e.target.name]: e.target.value });
  };

  const handleAddUserSubmit = async (e) => {
    e.preventDefault();
    if (role !== 'ADMIN') return alert('You do not have permission to add users.');
    if (newUser.password !== newUser.passwordConfirmation)
      return alert('Passwords do not match.');

    try {
      await axios.post('/api/users', newUser, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchUsers();
      setNewUser({ fullName: '', email: '', login: '', password: '', passwordConfirmation: '', role: 'USER' });
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

  if (!isLoggedIn) {
    return <div><h2>Please log in to access the user management page</h2></div>;
  }

  return (
    <div className="users">
      <header className="Main">
        <div className="nav_left">
          <div className="logo" onClick={() => navigate('/Main')}>
            <p>DesignQuery</p>
          </div>
          <nav>
            <div
              className={`folder ${activeFolder === 'users' ? 'active' : ''}`}
              onClick={() => setActiveFolder('users')}
            >
              <a href="/Users" className="nav_item">Users</a>
            </div>
            <div
              className={`folder ${activeFolder === 'admin' ? 'active' : ''}`}
              onClick={() => setActiveFolder('admin')}
            >
              <a href="/AdminPanel" className="nav_item">Admin Panel</a>
            </div>
          </nav>
        </div>
        <div className="nav_right">
          <div onClick={() => setUserProfileVisible(!userProfileVisible)} className="user_info">
            <div className="user_inform">
              {/* Conditionally render the role only if userData is loaded */}
              <p><strong>{userData ? userData.role : 'Loading...'}</strong></p>
              <span className="user_name">{userData ? userData.fullName : 'Guest'}</span>
            </div>
            <img src={userProfileImage} alt="Profile" className="user_image" />
          </div>
          {userProfileVisible && (
            <div className="dropdown_menu">
              <button className="dropdown_item" onClick={() => navigate('/Profile')}>My Profile</button>
              <button className="logout_button" onClick={handleLogout}>Log out</button>
            </div>
          )}
        </div>
      </header>

      <div className='main_container'>
        {/* Add User Form */}
        <div className="add_user_container">
          <h3>Add New User</h3>
          <form onSubmit={handleAddUserSubmit} className="add_user_form">
            {['fullName', 'email', 'login', 'password', 'passwordConfirmation'].map((field) => (
              <input
                key={field}
                type={field.includes('password') ? 'password' : 'text'}
                name={field}
                value={newUser[field]}
                placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                onChange={handleAddUserChange}
                required
              />
            ))}
            <select name="role" value={newUser.role} onChange={handleAddUserChange}>
              <option value="USER">User</option>
              <option value="ADMIN">Admin</option>
            </select>
            <button type="submit" className="add_user_button">Add User</button>
          </form>
        </div>

        {/* Search Bar */}
        <div className="search_bar_container">
          <input
            type="text"
            placeholder="Search by name or username"
            value={searchQuery}
            className="search_input"
          />
        </div>

        {/* Users List */}
        <div className="users_list_container">
          {filteredUsers.map((user) => (
            <div key={user.id} className="user_card">
              <div className="user_data">
                <img src={user.profilePicture || '/icons/default-avatar.png'} alt="Profile" className="user_image" />
                <div className="user_details">
                  <p>Full Name: {user.fullName}</p>
                  <p>Username: {user.login}</p>
                  <p>Email: {user.email}</p>
                  <p>Role: {user.role}</p>
                </div>
              </div>
              <div className="user_actions">
                <button
                  onClick={() => handleRoleChange(user.id, user.role === 'USER' ? 'ADMIN' : 'USER')}
                  className="role_change_button"
                >
                  Set as {user.role === 'USER' ? 'Admin' : 'User'}
                </button>
                <button onClick={() => handleUserDelete(user.id)} className="delete_user_button">
                  Delete User
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Users;
