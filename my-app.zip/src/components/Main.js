import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Main = () => {
  const [isHovered, setIsHovered] = useState({ like: null, dislike: null });
  const [activeFolder, setActiveFolder] = useState('main');
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [posts, setPosts] = useState([]);
  const [userProfileImage, setUserProfileImage] = useState('/icons/default-avatar.png');
  const [userProfileVisible, setUserProfileVisible] = useState(false);
  const [userData, setUserData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [isCategoryDropdownVisible, setIsCategoryDropdownVisible] = useState(false);
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [likedComments, setLikedComments] = useState(new Set());
  const [originalPosts, setOriginalPosts] = useState([]);
  const [post, setPost] = useState(null);

  // Comments
  const [newCommentContent, setNewCommentContent] = useState("");
  const [newReplyContent, setNewReplyContent] = useState("");
  const [commentsVisible, setCommentsVisible] = useState({});
  const [replyingToCommentId, setReplyingToCommentId] = useState(null);

  const userName = localStorage.getItem('fullName');
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  const role = localStorage.getItem('role');

  const navigate = useNavigate();

  useEffect(() => {
    if (token) {
      fetchPosts();
      fetchUserProfile();
      fetchCategories();
    } else {
      setIsLoggedIn(false);
    }
  }, [token]);
  const fetchPosts = async () => {
    try {
      const response = await axios.get('/api/posts', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setPosts(response.data.posts);
      setOriginalPosts(response.data.posts);
    } catch (error) {
      console.error('Error fetching posts', error);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setUserProfileImage(response.data.profilePicture || '/icons/default-avatar.png');
      setUserData(response.data);
    } catch (error) {
      console.error('Error fetching user profile', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/categories', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories', error);
    }
  };

  const handleReplyClick = (comment) => {
    setReplyingToCommentId(comment.id);
    setNewReplyContent("");
  };

  const handleCancelReply = () => {
    setReplyingToCommentId(null);
    setNewReplyContent("");
  };

  const handleReplySubmit = async (postId, parentCommentId) => {
    if (!newReplyContent.trim()) {
      alert('Reply cannot be empty!');
      return;
    }
  
    try {
      await axios.post(
        `/api/comments/${postId}/${parentCommentId}/replies`, // The correct endpoint for posting a reply
        { content: newReplyContent },
        { headers: { Authorization: `Bearer ${token}` } } // Include authorization in the headers
      );
  
      setNewReplyContent('');
  
      fetchPosts();
    } catch (error) {
      console.error('Error submitting reply', error);
    }
  };
  

const handleReplyDelete = async (postId, commentId, replyId) => {
  try {
    const response = await fetch(`/api/comments/${postId}/${commentId}/replies/${replyId}`, {
      method: 'DELETE',
    });

    if (response.ok) {
      const updatedPost = {
        ...post,
        comments: post.comments.map(comment => 
          comment.id === commentId
            ? { ...comment, replies: comment.replies.filter(reply => reply.id !== replyId) }
            : comment
        ),
      };
      setPost(updatedPost); // Update post state with the deleted reply
    }
  } catch (err) {
    console.error('Error deleting reply:', err);
  }
};

const handleReplyUpdate = async (postId, commentId, replyId, updatedContent) => {
  try {
    const response = await fetch(`/api/comments/${postId}/${commentId}/replies/${replyId}`, {
      method: 'PATCH',
      body: JSON.stringify({ content: updatedContent }),
      headers: {
        'Content-Type': 'application/json',
      },
    });

    const updatedReply = await response.json();
    if (response.ok) {
      const updatedPost = {
        ...post,
        comments: post.comments.map(comment =>
          comment.id === commentId
            ? {
                ...comment,
                replies: comment.replies.map(reply =>
                  reply.id === replyId ? { ...reply, content: updatedReply.content } : reply
                ),
              }
            : comment
        ),
      };
      setPost(updatedPost); // Update the post state with the updated reply
    }
  } catch (err) {
    console.error('Error updating reply:', err);
  }
};

  const handleLikeDislike = async (postId, type) => {
    try {
      await axios.post(
        `/api/posts/${postId}/likes`,
        { type },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      
      if (type === 'LIKE') {
        setLikedPosts((prev) => new Set(prev.add(postId)));  // Додаємо пост в набір для лайків
      } else {
        setLikedPosts((prev) => {
          const newSet = new Set(prev);
          newSet.delete(postId);
          return newSet;
        });
      }
  
      fetchPosts();
    } catch (error) {
      console.error('Error liking/disliking post', error);
    }
  };
  

  const handleCommentLike = async (commentId, type) => {
    try {
      await axios.post(
        `/api/comments/${commentId}/likes`,
        { type }, // 'LIKE' or 'DISLIKE'
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (type === 'LIKE') {
        setLikedComments((prev) => new Set(prev).add(commentId));
      } else {
        setLikedComments((prev) => {
          const newSet = new Set(prev);
          newSet.delete(commentId);
          return newSet;
        });
      }
    } catch (error) {
      console.error('Error liking/disliking comment', error);
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    const filtered = originalPosts.filter(
      (post) =>
        post.title.toLowerCase().includes(query.toLowerCase()) ||
        post.content.toLowerCase().includes(query.toLowerCase())
    );
    setPosts(filtered);
  };

  const Comment = ({ comment, onDelete, onUpdate }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editContent, setEditContent] = useState(comment.content);
  
    const handleEditSave = () => {
      if (editContent.trim()) {
        onUpdate(comment.id, editContent); // Оновлення коментаря
        setIsEditing(false); // Закриття режиму редагування
      } else {
        alert("Comment content can't be empty!");
      }
    };
  
    return (
      <div className="comment_box">
        {isEditing ? (
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            className="edit_input"
          />
        ) : (
          <p>{comment.content}</p>
        )}
  
        {(userData?.role === 'ADMIN' || comment.author?.id === userId) && (
          <>
          <div className="edit_and_delete_container">
            {isEditing ? (
              <button onClick={handleEditSave} className="save_button">
                Save
              </button>
            ) : (
              <button onClick={() => setIsEditing(true)} className="edit_button">
                Edit
              </button>
            )}
            <button onClick={() => onDelete(comment.id)} className="delete_button">
              Delete
            </button>
            </div>
          </>
        )}
      </div>
    );
  };
  

const handleCommentUpdate = async (commentId, content) => {
  try {
    await axios.patch(
      `/api/comments/${commentId}`,
      { content },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    // Оновлення локального стану постів після редагування
    setPosts((prevPosts) =>
      prevPosts.map((post) => ({
        ...post,
        comments: post.comments.map((comment) =>
          comment.id === commentId ? { ...comment, content } : comment
        ),
      }))
    );
  } catch (err) {
    console.error('Error updating comment', err);
  }
};

const handleCommentDelete = async (commentId) => {
  try {
      await axios.delete(`/api/comments/${commentId}`, {
          headers: { Authorization: `Bearer ${token}` },
      });
      // Refresh posts/comments
      fetchPosts();
  } catch (err) {
      console.error('Error deleting comment', err);
  }
};

const handleCommentSubmit = async (postId) => {
  if (!newCommentContent.trim()) {
    alert('Comment cannot be empty!');
    return;
  }

  try {
    await axios.post(
      `/api/posts/${postId}/comments`,
      { content: newCommentContent },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    setNewCommentContent('');

    fetchPosts();
  } catch (error) {
    console.error('Error submitting comment', error);
  }
};

// Fetch posts for selected categories
const fetchPostsByCategory = async (categoryId) => {
  try {
    const response = await axios.get(`/api/categories/${categoryId}/posts`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (response.data && response.data.length > 0) {
      setPosts(response.data);
    } else {
      setPosts([]); // Clear posts if no posts found
    }
  } catch (error) {
    console.error('Error fetching posts by category:', error);
    setPosts([]); // Clear posts in case of error
  }
};



useEffect(() => {
  if (selectedCategories.length === 1) {
    fetchPostsByCategory(selectedCategories[0]);
  } else if (selectedCategories.length === 0) {
    fetchPosts();
  } else {
    fetchPosts();
  }
}, [selectedCategories]);

// Modify handleCategoryCheckboxChange to allow single-category filtering
const handleCategoryCheckboxChange = (categoryId) => {
  if (selectedCategories.includes(categoryId)) {
    setSelectedCategories([]); // Deselect category
  } else {
    setSelectedCategories([categoryId]); // Select only this category
  }
};

const handleCategoryChange = (categoryId) => {
  if (selectedCategories.includes(categoryId)) {
    // Remove category if already selected
    setSelectedCategories((prev) =>
      prev.filter((id) => id !== categoryId)
    );
  } else {
    // Add category if not already selected
    setSelectedCategories((prev) => [...prev, categoryId]);
  }
};

const filteredPosts = () => {
  if (selectedCategories.length === 0) {
    return posts;
  }
  return posts.filter((post) =>
    post.categories.some((category) =>
      selectedCategories.includes(category.id)
    )
  );
};

  const toggleCategoryDropdown = () => {
    setIsCategoryDropdownVisible(!isCategoryDropdownVisible);
  };


  const handleCategorySelection = (categoryId) => {
    if (selectedCategoryId === categoryId) {
      setSelectedCategoryId(null); // Deselect if the same category is clicked again
      fetchPosts(); // Fetch all posts if no category is selected
    } else {
      setSelectedCategoryId(categoryId);
      fetchPostsByCategory(categoryId); // Fetch posts for the selected category
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout', {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      localStorage.clear();

      setIsLoggedIn(false);

      navigate('/SignIn');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const toggleComments = (postId) => {
    setCommentsVisible((prevState) => ({
      ...prevState,
      [postId]: !prevState[postId],
    }));
  };

  if (!isLoggedIn) {
    return (
      <div>
        <h2>Please log in to access the posts</h2>
      </div>
    );
  }

  return (
    <div className="main">
      <header className="Main">
        <div className="nav_left">
          <div className="logo" onClick={() => navigate('/Main')}>
            <p>DesignQuery</p>
          </div>
          <nav>
            <div className={`folder ${activeFolder === 'users' ? 'active' : ''}`} onClick={() => setActiveFolder('users')}>
              <a href="/Users" className="nav_item">Users</a>
            </div>
            <div className={`folder ${activeFolder === 'admin' ? 'active' : ''}`} onClick={() => setActiveFolder('admin')}>
              <a href="/AdminPanel" className="nav_item">Admin Panel</a>
            </div>
          </nav>
        </div>
        <div className="nav_right">
          <div onClick={() => setUserProfileVisible(!userProfileVisible)} className="user_info">
            <div className="user_inform">
              <p><strong>{userData ? userData.role : 'Loading...'}</strong></p>
              <span className="user_name">{userData ? userData.fullName : 'Guest'}</span>
            </div>
            <img src={userProfileImage} alt="Profile" className="user_image" />
          </div>
          {userProfileVisible && (
            <div className="dropdown_menu">
              <button className="dropdown_item" onClick={() => navigate('/Profile')}>My Profile</button>
              <button className="dropdown_item" onClick={handleLogout}>Log out</button>
            </div>
          )}
        </div>
      </header>

      <div className='main_container'>
        <div className='search_and_filter_container'>

            {/* Search bar */}
            <div className="search_bar">
            <div className="search_input">
              <input
                type="text"
                placeholder="Search by title or content"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                style={{ paddingLeft: '60px', width: '100%' }}
              />
              <img src="/icons/search.svg" alt="Search" />
            </div>
          </div>
          
          {/* Filter by category */}
          <div className="category_filter_container">
            <div className="category_filter">
            <button onClick={() => setIsCategoryDropdownVisible(!isCategoryDropdownVisible)} className="filter_button">
              <span>Filter by category</span>
              <img
                src={`/icons/${isCategoryDropdownVisible ? 'hide-categories.svg' : 'show-categories.svg'}`}
                alt="Toggle categories"
              />
            </button>
            {isCategoryDropdownVisible && (
              <div className="categories_dropdown">
                {categories.map((category) => (
                  <div key={category.id} className="category_item">
                    <input
                      className='checkbox'
                      type="checkbox"
                      id={`category-${category.id}`}
                      checked={selectedCategoryId === category.id}
                      onChange={() => handleCategorySelection(category.id)}
                    />
                    <label htmlFor={`category-${category.id}`}>{category.title}</label>
                  </div>
                ))}
              </div>
            )}
            </div>
          </div>
        </div>

        <div className="main_content">
  {posts.length > 0 ? (
    posts.map((post) => (
      <div key={post.id} className="post_container">
        <div className="post_header">
          <div className="post_user_info">
            <img
              src={post.author?.profilePicture || '/icons/default-avatar.png'}
              alt="User profile"
              className="profile_img"
            />
            <p>{post.author?.fullName || 'Unknown User'}</p>
          </div>
          <div className="post_reactions">
            <button
              className={`like_button ${likedPosts.has(post.id) ? 'liked' : ''} ${isHovered.like === post.id ? 'hovered' : ''}`}
              onClick={() => handleLikeDislike(post.id, 'LIKE')}
              onMouseEnter={() => setIsHovered({ ...isHovered, like: post.id })}
              onMouseLeave={() => setIsHovered({ ...isHovered, like: null })}
            >
              <img
                src={`/icons/Like on post/${likedPosts.has(post.id) ? 'Liked' : (isHovered.like === post.id ? 'Hover' : 'Default')}.svg`}
                alt="Like"
              />
            </button>
            <button
              className={`dislike_button ${likedPosts.has(post.id) ? 'disliked' : ''} ${isHovered.dislike === post.id ? 'hovered' : ''}`}
              onClick={() => handleLikeDislike(post.id, 'DISLIKE')}
              onMouseEnter={() => setIsHovered({ ...isHovered, dislike: post.id })}
              onMouseLeave={() => setIsHovered({ ...isHovered, dislike: null })}
            >
              <img
                src={`/icons/Dislike on post/${likedPosts.has(post.id) ? 'Disliked' : (isHovered.dislike === post.id ? 'Hover' : 'Default')}.svg`}
                alt="Dislike"
              />
            </button>
          </div>
        </div>
        <h2 className="post_title">{post.title}</h2>
        <p className="post_content">{post.content}</p>
        <p className="post_category">
          <strong>Categories: </strong> 
          {post.categories && post.categories.length > 0 ? 
            post.categories.map((category) => category.title).join(' | ') :
            "No category"
          }
        </p>

        <div className="comments_section">
      <button
        onClick={() => toggleComments(post.id)}
        className="comment_toggle_button"
      >
        <span>Comments</span>
        {commentsVisible[post.id] ? (
          <img src="/icons/hide-comments-icon.svg" alt="Hide comments" />
        ) : (
          <img src="/icons/show-comments-icon.svg" alt="Show comments" />
        )}
      </button>

      {commentsVisible[post.id] && (
        <div className="comments_list">
          {post.comments?.length > 0 ? (
            post.comments.map((comment) => (
              <div key={comment.id} className="comment">
                <Comment
                  comment={comment}
                  onDelete={handleCommentDelete}
                  onUpdate={handleCommentUpdate}
                />
                {/* Reply Button */}
                <button 
                  onClick={() => handleReplyClick(comment)} 
                  className="reply_button"
                >
                  Reply
                </button>

                {/* Render replies for each comment */}
                {comment.replies && comment.replies.map((reply) => (
                  <div key={reply.id} className="reply">
                    <p>{reply.content}</p>
                    <button onClick={() => handleReplyDelete(post.id, comment.id, reply.id)}>Delete Reply</button>
                    <button onClick={() => handleReplyUpdate(post.id, comment.id, reply.id, "Updated content")}>Edit Reply</button>
                  </div>
                ))}
              </div>
            ))
          ) : (
            <p>No comments yet</p>
          )}

          {/* Form to create a new comment */}
          <div className="create_comment">
            {replyingToCommentId ? (
              // Reply to comment input
              <div className="create_reply">
                <textarea
                  value={newReplyContent}
                  onChange={(e) => setNewReplyContent(e.target.value)}
                  placeholder="Write your reply here..."
                  className="comment_input"
                />
                <div className="post_comment_actions">
                <button
                  onClick={() => handleReplySubmit(post.id, replyingToCommentId, newReplyContent)}
                  className="submit_comment_button"
                >
                  Post reply
                </button>
                <button
                  onClick={handleCancelReply} // Cancel the reply
                  className="cancel_comment_button"
                >
                  Cancel
                </button>
              </div>
              </div>
            ) : (
              // Create new comment input
              <div>
                <textarea
                  value={newCommentContent}
                  onChange={(e) => setNewCommentContent(e.target.value)}
                  placeholder="Write your comment here..."
                  className="comment_input"
                />
                <div className="post_comment_actions">
                <button
                  onClick={() => handleCommentSubmit(post.id, newCommentContent)}
                  className="submit_comment_button"
                >
                  Post comment
                </button>
                <button
                  onClick={() => setNewCommentContent('')} // Clear input when cancel is clicked
                  className="cancel_comment_button"
                >
                  Cancel
                </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>


      </div>
    ))
  ) : (
    <p className="not_found">No posts found</p>
  )}
</div>


        
      </div>
    </div>
  );
};

export default Main;
