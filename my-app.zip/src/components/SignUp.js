import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SignUp = () => {
  const [formData, setFormData] = useState({
    login: '',
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const validateLogin = (login) => {
    if (!login) return 'Login is required.';
    if (login.length < 6 || login.length > 24) return 'Login must be between 6 and 24 characters.';
    return '';
  };

  const validateFullName = (fullName) => {
    if (!fullName) return 'Full name is required.';
    if (fullName.length < 3 || fullName.length > 64) return 'Name must be between 3 and 64 characters.';
    return '';
  };

  const validateEmail = (email) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return 'Email is required.';
    if (!emailPattern.test(email)) return 'Enter a valid email address.';
    return '';
  };

  const validatePassword = (password) => {
    if (!password) return 'Password is required.';
    if (password.length < 8) return 'Password must be at least 8 characters long.';
    if (!/[a-z]/.test(password)) return 'Password must include at least one lowercase letter.';
    if (!/[A-Z]/.test(password)) return 'Password must include at least one uppercase letter.';
    if (!/\d|\W/.test(password)) return 'Password must include at least one number or symbol.';
    return '';
  };

  const validateConfirmPassword = (password, confirmPassword) => {
    if (password !== confirmPassword) return 'Passwords do not match.';
    return '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    let error = '';
    if (name === 'login') error = validateLogin(value);
    else if (name === 'fullName') error = validateFullName(value);
    else if (name === 'email') error = validateEmail(value);
    else if (name === 'password') error = validatePassword(value);
    else if (name === 'confirmPassword') error = validateConfirmPassword(formData.password, value);

    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: error,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = {
      login: validateLogin(formData.login),
      fullName: validateFullName(formData.fullName),
      email: validateEmail(formData.email),
      password: validatePassword(formData.password),
      confirmPassword: validateConfirmPassword(formData.password, formData.confirmPassword),
    };

    setErrors(validationErrors);

    if (Object.values(validationErrors).some((error) => error)) return;

    try {
      setIsSubmitting(true);

      const response = await axios.post('api/auth/register', {
        login: formData.login,
        fullName: formData.fullName,
        email: formData.email,
        password: formData.password,
        passwordConfirmation: formData.confirmPassword,
      });

      const { token, userId, role, fullName } = response.data;
      localStorage.setItem('token', token);
      localStorage.setItem('userId', userId);
      localStorage.setItem('role', role);
      localStorage.setItem('fullName', fullName);

      navigate('/SignIn');
    } catch (err) {
      console.error('Registration error:', err.response || err);
      const serverErrors = err.response?.data?.errors || { server: 'An error occurred while registering.' };
      setErrors(serverErrors);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <header className="header">
        <p className="logo">DesignQuery</p>
      </header>
      <div className="sign_up">
        <div className="overlay_text">
          <div className="infotext">
            <h1>Welcome Back!</h1>
            <p>Let's dive into more learning with us.</p>
          </div>
          <button type="button" className="sign_in_button" onClick={() => navigate('/SignIn')}>
            Sign in
          </button>
        </div>
        <div className="form_container">
          <h1>Create Account</h1>
          <form onSubmit={handleSubmit} noValidate>
            <div className="container">
              <div className="input_box">
                <label htmlFor="login">Login<span className="required"> *</span></label>
                <input
                  type="text"
                  id="login"
                  name="login"
                  placeholder="Enter your login"
                  value={formData.login}
                  onChange={handleChange}
                  required
                />
                {errors.login && <small className="error">{errors.login}</small>}
              </div>
              <div className="input_box">
                <label htmlFor="fullName">Full Name<span className="required"> *</span></label>
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                />
                {errors.fullName && <small className="error">{errors.fullName}</small>}
              </div>
              <div className="input_box">
                <label htmlFor="email">Email<span className="required"> *</span></label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                {errors.email && <small className="error">{errors.email}</small>}
              </div>
              <div className="input_box">
                <label htmlFor="password">Password<span className="required"> *</span></label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                {errors.password && <small className="error">{errors.password}</small>}
              </div>
              <div className="input_box">
                <label htmlFor="confirmPassword">Confirm Password<span className="required"> *</span></label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  placeholder="Repeat your password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
                {errors.confirmPassword && <small className="error">{errors.confirmPassword}</small>}
              </div>
              {errors.server && <small className="error">{errors.server}</small>}
              <button
                type="submit"
                className="button"
                disabled={isSubmitting || Object.values(errors).some((error) => error)}
              >
                {isSubmitting ? 'Creating Account...' : 'Create Account'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
