import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AdminPanel = () => {
  const [isHovered, setIsHovered] = useState({ like: null, dislike: null });
  const [activeFolder, setActiveFolder] = useState('main');
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [posts, setPosts] = useState([]);
  const [commentsVisible, setCommentsVisible] = useState({});
  const [userProfileImage, setUserProfileImage] = useState('/icons/default-avatar.png');
  const [userProfileVisible, setUserProfileVisible] = useState(false);
  const [userData, setUserData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [isCategoryDropdownVisible, setIsCategoryDropdownVisible] = useState(false);
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [originalPosts, setOriginalPosts] = useState([]);
  const [likedComments, setLikedComments] = useState(new Set());

  const userName = localStorage.getItem('fullName');
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  const role = localStorage.getItem('role');
  const searchRef = useRef(null);

  const navigate = useNavigate();

  useEffect(() => {
    if (token) {
      fetchPosts();
      fetchUserProfile();
      fetchCategories();
    } else {
      setIsLoggedIn(false);
    }
  }, [token]);

  const fetchPosts = async () => {
    try {
      const response = await axios.get('/api/posts', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setPosts(response.data.posts);
    } catch (error) {
      console.error('Error fetching posts', error);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setUserProfileImage(response.data.profilePicture || '/icons/default-avatar.png');
      setUserData(response.data);
    } catch (error) {
      console.error('Error fetching user profile', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/categories', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories', error);
    }
  };
  
  const handleSearch = (query) => {
    setSearchQuery(query);
    const filtered = posts.filter(
      (post) =>
        post.title.toLowerCase().includes(query.toLowerCase()) ||
        post.content.toLowerCase().includes(query.toLowerCase())
    );
    setPosts(filtered);
  };

  const handleCategoryCheckboxChange = (categoryId) => {
    setSelectedCategories((prevSelected) =>
      prevSelected.includes(categoryId)
        ? prevSelected.filter((id) => id !== categoryId)
        : [...prevSelected, categoryId]
    );
  };

  const toggleCategoryDropdown = () => {
    setIsCategoryDropdownVisible(!isCategoryDropdownVisible);
  };

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout', {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      localStorage.clear();

      setIsLoggedIn(false);

      navigate('/SignIn');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const toggleComments = (postId) => {
    setCommentsVisible((prevState) => ({
      ...prevState,
      [postId]: !prevState[postId],
    }));
  };

  if (!isLoggedIn) {
    return (
      <div>
        <h2>Please log in to access the posts</h2>
      </div>
    );
  }

  return (
    <div className="adminPanel">
      <header className="Main">
        <div className="nav_left">
          <div className="logo" onClick={() => navigate('/Main')}>
            <p>DesignQuery</p>
          </div>
          <nav>
            <div
              className={`folder ${activeFolder === 'users' ? 'active' : ''}`}
              onClick={() => setActiveFolder('users')}
            >
              <a href="/Users" className="nav_item">Users</a>
            </div>

            <div
              className={`folder ${activeFolder === 'admin' ? 'active' : ''}`}
              onClick={() => setActiveFolder('admin')}
            >
              <a href="/AdminPanel" className="nav_item">Admin Panel</a>
            </div>
          </nav>
        </div>
        <div className="nav_right">
          <div onClick={() => setUserProfileVisible(!userProfileVisible)} className="user_info">
          <div className="user_inform">
          <p><strong>{userData ? userData.role : 'Loading...'}</strong></p>
            <span className="user_name">{userData ? userData.fullName : 'Guest'}</span>
          </div>
            <img src={userProfileImage} alt="Profile" className="user_image" />
          </div>
          {userProfileVisible && (
            <div className="dropdown_menu">
              <button className="dropdown_item" onClick={() => navigate('/Profile')}>My Profile</button>
              <button className="dropdown_item" onClick={handleLogout}>Log out</button>
            </div>
          )}
        </div>
      </header>

      <div className='main_container'>
        <div className='search_and_filter_container'>
          {/* Search bar */}
          <div className="search_bar">
            <div className="search_input">
              <input
                type="text"
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                style={{ paddingLeft: '60px', width: '100%' }}
              />
              <img src="/icons/search.svg" alt="Search" />
            </div>
          </div>

          {/* Filter by category */}
          <div className="category_filter_container">
            <div className="category_filter">
              <button onClick={toggleCategoryDropdown} className="filter_button">
                <span>Filter by category</span>
                <img
                  src={`/icons/${isCategoryDropdownVisible ? 'hide-categories.svg' : 'show-categories.svg'}`}
                  alt="Toggle categories"
                />
              </button>
              {isCategoryDropdownVisible && (
                <div className="categories_dropdown">
                  {categories.map((category) => (
                    <div key={category.id} className="category_item">
                      <input
                        className='checkbox'
                        type="checkbox"
                        id={`category-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onChange={() => handleCategoryCheckboxChange(category.id)}
                      />
                      <label htmlFor={`category-${category.id}`}>{category.title}</label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        </div>
    </div>
  );
};

export default AdminPanel;
