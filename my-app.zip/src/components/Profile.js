import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const [post, setPost] = useState(null);
  const [allPosts, setAllPosts] = useState([]); 
  const [isHovered, setIsHovered] = useState({ like: null, dislike: null });
  const [activeFolder, setActiveFolder] = useState('main');
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [posts, setPosts] = useState([]);
  const [userProfileImage, setUserProfileImage] = useState('/icons/default-avatar.png');
  const [userProfileVisible, setUserProfileVisible] = useState(false);
  const [userData, setUserData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [isCategoryDropdownVisible, setIsCategoryDropdownVisible] = useState(false);
  const [isFilterCategoryDropdownVisible, setIsFilterCategoryDropdownVisible] = useState(false);
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [likedComments, setLikedComments] = useState(new Set());
  const [newCategoryData, setNewCategoryData] = useState({ title: '' });
  const [editing, setEditing] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [originalPosts, setOriginalPosts] = useState([]);

    // Comments
    const [newCommentContent, setNewCommentContent] = useState("");
    const [newReplyContent, setNewReplyContent] = useState("");
    const [commentsVisible, setCommentsVisible] = useState({});
    const [replyingToCommentId, setReplyingToCommentId] = useState(null);

  const [newPostData, setNewPostData] = useState({
    title: '',
    content: '',
    categories: [],
  });
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    login: '',
    profilePicture: null,
  });

  const userName = localStorage.getItem('fullName');
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  const role = localStorage.getItem('role');
  const searchRef = useRef(null);
  const navigate = useNavigate();
  const [isSelectCategoryDropdownVisible, setIsSelectCategoryDropdownVisible] = useState(false);
  const [filterCategories, setFilterCategories] = useState([]);

  useEffect(() => {
    if (token) {
      fetchMyPosts();
      fetchUserProfile();
      fetchCategories();
    } else {
      setIsLoggedIn(false);
    }
  }, [token]);

  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUserData(response.data);
      setFormData({
        fullName: response.data.fullName,
        email: response.data.email,
        login: response.data.login,
        profilePicture: null,
      });
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/categories', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchMyPosts = async () => {
    try {
      const response = await axios.get('/api/posts/', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setAllPosts(response.data.posts);
      setPosts(response.data.posts);
    } catch (error) {
      console.error('Error fetching user posts:', error);
    }
  };
  const handleReplyClick = (comment) => {
    setReplyingToCommentId(comment.id);
    setNewReplyContent("");
  };

  const handleCancelReply = () => {
    setReplyingToCommentId(null);
    setNewReplyContent("");
  };

  const handleReplySubmit = async (postId, parentCommentId) => {
    if (!newReplyContent.trim()) {
      alert('Reply cannot be empty!');
      return;
    }
  
    try {
      await axios.post(
        `/api/comments/${postId}/${parentCommentId}/replies`, // The correct endpoint for posting a reply
        { content: newReplyContent },
        { headers: { Authorization: `Bearer ${token}` } } // Include authorization in the headers
      );
  
      setNewReplyContent('');
  
      fetchMyPosts();
    } catch (error) {
      console.error('Error submitting reply', error);
    }
  };

const handleReplyDelete = async (postId, commentId, replyId) => {
  try {
    const response = await fetch(`/api/comments/${postId}/${commentId}/replies/${replyId}`, {
      method: 'DELETE',
    });

    if (response.ok) {
      const updatedPost = {
        ...post,
        comments: post.comments.map(comment => 
          comment.id === commentId
            ? { ...comment, replies: comment.replies.filter(reply => reply.id !== replyId) }
            : comment
        ),
      };
      setPost(updatedPost);
    }
  } catch (err) {
    console.error('Error deleting reply:', err);
  }
};

const handleReplyUpdate = async (postId, commentId, replyId, updatedContent) => {
  try {
    const response = await fetch(`/api/comments/${postId}/${commentId}/replies/${replyId}`, {
      method: 'PATCH',
      body: JSON.stringify({ content: updatedContent }),
      headers: {
        'Content-Type': 'application/json',
      },
    });

    const updatedReply = await response.json();
    if (response.ok) {
      const updatedPost = {
        ...post,
        comments: post.comments.map(comment =>
          comment.id === commentId
            ? {
                ...comment,
                replies: comment.replies.map(reply =>
                  reply.id === replyId ? { ...reply, content: updatedReply.content } : reply
                ),
              }
            : comment
        ),
      };
      setPost(updatedPost); // Update the post state with the updated reply
    }
  } catch (err) {
    console.error('Error updating reply:', err);
  }
};

  const toggleSelectCategoryDropdown = () => {
    setIsSelectCategoryDropdownVisible(!isSelectCategoryDropdownVisible);
    setIsFilterCategoryDropdownVisible(false);
  };

  const toggleFilterCategoryDropdown = () => {
    setIsFilterCategoryDropdownVisible((prev) => !prev);
    setIsSelectCategoryDropdownVisible(false);
  };

  const handleSelectCategoryChange = (categoryId) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleFilterCategoryChange = (categoryId) => {
    setFilterCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  useEffect(() => {
    if (filterCategories.length > 0) {
      fetchMyPostsByCategories();
    } else {
      fetchMyPosts();
    }
  }, [filterCategories]);

  const fetchMyPostsByCategories = async (categoryId) => {
    try {
      const response = await axios.get(`/api/categories/${categoryId}/posts`, {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      if (response.data && response.data.length > 0) {
        setPosts(response.data);
      } else {
        setPosts([]);  // Якщо немає постів для цієї категорії
      }
    } catch (error) {
      console.error('Error fetching posts by category:', error);
      setPosts([]);  // Виводимо порожній список постів у разі помилки
    }
  };
  

  const handleCreatePost = async (e) => {
    e.preventDefault();
    if (selectedCategories.length === 0) {
      alert('Please select at least one category.');
      return;
    }
    try {
      const postData = {
        title: newPostData.title,
        content: newPostData.content,
        categories: selectedCategories,
      };
      const response = await axios.post('/api/posts', postData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNewPostData({ title: '', content: '', categories: [] });
      setSelectedCategories([]);
      fetchMyPosts();
    } catch (error) {
      console.error('Error creating new post:', error);
    }
  };
  
  const handleCreateCategory = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/categories', newCategoryData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchCategories();
      setNewCategoryData({ title: '' });
    } catch (error) {
      console.error('Error creating new category:', error);
    }
  };

  const handleCategorySelection = (categoryId) => {
    setSelectedCategories((prev) => {
      if (prev.includes(categoryId)) {
        return prev.filter((id) => id !== categoryId);
      } else {
        return [...prev, categoryId];
      }
    });
  };

  const handleEditToggle = () => {
    setEditing(!editing);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setFormData(prevData => ({
      ...prevData,
      profilePicture: file,
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleNewPostChange = (e) => {
    const { name, value } = e.target;
    setNewPostData({ ...newPostData, [name]: value });
  };

  const handleNewCategoryChange = (e) => {
    const { name, value } = e.target;
    setNewCategoryData({ ...newCategoryData, [name]: value });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      if (formData.profilePicture) {
        const avatarData = new FormData();
        avatarData.append('profilePicture', formData.profilePicture);

        await axios.post(`/api/users/avatar`, avatarData, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        });
      }

      await axios.patch(
        `/api/users/me`,
        {
          fullName: formData.fullName,
          email: formData.email,
          login: formData.login,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      fetchUserProfile();
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const handleSubmitEditPost = async (e, postId) => {
    e.preventDefault();
  
    if (!newPostData.title.trim() || !newPostData.content.trim()) {
      alert('Title and content are required.');
      return;
    }
  
    if (newPostData.categories.length === 0) {
      alert('Please select at least one category.');
      return;
    }
  
    try {
      const updatedPost = {
        title: newPostData.title,
        content: newPostData.content,
        categories: newPostData.categories,
      };
  
      await axios.patch(`/api/posts/${postId}`, updatedPost, {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      setEditingPost(null);
      setNewPostData({ title: '', content: '', categories: [] });
      fetchMyPosts(); // Оновлення списку постів
    } catch (error) {
      console.error('Error editing post:', error);
    }
  };
  

  const handleLikeDislike = async (postId, type) => {
    try {
      await axios.post(
        `/api/posts/${postId}/likes`,
        { type },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      
      if (type === 'LIKE') {
        setLikedPosts((prev) => new Set(prev.add(postId)));
      } else {
        setLikedPosts((prev) => {
          const newSet = new Set(prev);
          newSet.delete(postId);
          return newSet;
        });
      }
  
      fetchMyPosts();
    } catch (error) {
      console.error('Error liking/disliking post', error);
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    const filtered = allPosts.filter(
      (post) =>
        post.title.toLowerCase().includes(query.toLowerCase()) ||
        post.content.toLowerCase().includes(query.toLowerCase())
    );
    setPosts(filtered);
  };

  const Comment = ({ comment, onDelete, onUpdate }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editContent, setEditContent] = useState(comment.content);
  
    const handleEditSave = () => {
      if (editContent.trim()) {
        onUpdate(comment.id, editContent);
        setIsEditing(false);
      } else {
        alert("Comment content can't be empty!");
      }
    };
  
    return (
      <div className="comment_box">
        {isEditing ? (
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            className="edit_input"
          />
        ) : (
          <p>{comment.content}</p>
        )}
  
        {(userData?.role === 'ADMIN' || comment.author?.id === userId) && (
          <>
          <div className='edit_and_delete_container'>
            {isEditing ? (
              <button onClick={handleEditSave} className="save_button">
                Save
              </button>
            ) : (
              <button onClick={() => setIsEditing(true)} className="edit_button">
                Edit
              </button>
            )}
            <button onClick={() => onDelete(comment.id)} className="delete_button">
              Delete
            </button>
            </div>
          </>
        )}
      </div>
    );
  };
  

const handleCommentUpdate = async (commentId, content) => {
  try {
    await axios.patch(
      `/api/comments/${commentId}`,
      { content },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    setPosts((prevPosts) =>
      prevPosts.map((post) => ({
        ...post,
        comments: post.comments.map((comment) =>
          comment.id === commentId ? { ...comment, content } : comment
        ),
      }))
    );
  } catch (err) {
    console.error('Error updating comment', err);
  }
};

const handleCommentDelete = async (commentId) => {
  try {
      await axios.delete(`/api/comments/${commentId}`, {
          headers: { Authorization: `Bearer ${token}` },
      });
      fetchMyPosts();
  } catch (err) {
      console.error('Error deleting comment', err);
  }
};

const handleCommentSubmit = async (postId) => {
  if (!newCommentContent.trim()) {
    alert('Comment cannot be empty!');
    return;
  }

  try {
    await axios.post(
      `/api/posts/${postId}/comments`,
      { content: newCommentContent },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    setNewCommentContent('');

    fetchMyPosts();
  } catch (error) {
    console.error('Error submitting comment', error);
  }
};

const fetchMyPostsByCategory = async (categoryId) => {
  try {
    const response = await axios.get(`/api/categories/${categoryId}/posts`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (response.data && response.data.length > 0) {
      setPosts(response.data);
    } else {
      setPosts([]);
    }
  } catch (error) {
    console.error('Error fetching posts by category:', error);
    setPosts([]);
  }
};

useEffect(() => {
  if (selectedCategories.length > 0) {
    const fetchMyPostsByCategory = async () => {
      try {
        const categoryQueries = selectedCategories.map((categoryId) =>
          axios.get(`/api/categories/${categoryId}/posts`)
        );
        const responses = await Promise.all(categoryQueries);
        const postsData = responses.map((response) => response.data);
        const allPosts = postsData.flat();
        setPosts(allPosts);
      } catch (error) {
        console.error('Error fetching posts:', error);
      }
    };
    fetchMyPostsByCategory();
  } else {
    setPosts([]);
  }
}, [selectedCategories]);

const handleCategoryCheckboxChange = (categoryId) => {
  handleCategoryFilterChange(categoryId);
};

const handleCategoryFilterChange = (categoryId) => {
  setSelectedCategories((prev) =>
    prev.includes(categoryId)
      ? prev.filter((id) => id !== categoryId)
      : [...prev, categoryId]
  );
};

useEffect(() => {
  let filteredPosts = allPosts;

  // Фільтруємо за категорією, якщо вибрані категорії
  if (selectedCategories.length > 0) {
    filteredPosts = filteredPosts.filter((post) =>
      post.categories.some((category) => selectedCategories.includes(category.id))
    );
  }

  // Фільтруємо також за запитом пошуку
  if (searchQuery) {
    filteredPosts = filteredPosts.filter(
      (post) =>
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }

  // Оновлюємо список постів після фільтрації
  setPosts(filteredPosts);
}, [searchQuery, selectedCategories, allPosts]);

  const toggleCategoryDropdown = () => {
    setIsCategoryDropdownVisible(!isCategoryDropdownVisible);
  };

  const filteredPosts = () => {
    if (selectedCategories.length === 0) return posts;
    return posts.filter((post) => selectedCategories.includes(post.categoryId));
  };

  const handleLogout = async () => {
    try {
      await axios.post('/api/auth/logout', {}, {
        headers: { Authorization: `Bearer ${token}` },
      });

      localStorage.clear();

      setIsLoggedIn(false);

      navigate('/SignIn');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleCategoryChange = (categoryId) => {
    setNewPostData((prev) => ({
      ...prev,
      categories: prev.categories.includes(categoryId)
        ? prev.categories.filter((id) => id !== categoryId)
        : [...prev.categories, categoryId],
    }));
  };  

  const handleEditPost = (post) => {
    setEditingPost(post.id);
    setNewPostData({
      title: post.title,
      content: post.content,
      categories: post.categories.map((category) => category.id),
    });
  };

  const handleDeletePost = async (postId) => {
 
    try {
      const response = await axios.delete(`/api/posts/${postId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
  
      if (response.status === 200 || response.status === 204) {
        alert('Post deleted successfully!');
        fetchMyPosts(); // Перезавантаження списку постів після видалення
      } else {
        console.error('Unexpected response:', response);
        alert('Something went wrong. Please try again later.');
      }
    } catch (error) {
      console.error('Error deleting post:', error.response || error.message);
  
      if (error.response?.status === 403) {
        alert('You do not have permission to delete this post.');
      } else if (error.response?.status === 404) {
        alert('Post not found or already deleted.');
      } else {
        alert('Server error occurred. Please try again later.');
      }
    }
  };
  

const toggleComments = (postId) => {
  setCommentsVisible((prevState) => ({
    ...prevState,
    [postId]: !prevState[postId],
  }));
};

  if (!isLoggedIn) {
    return (
      <div>
        <h2>Please log in to access the posts</h2>
      </div>
    );
  }

  return (
    <div className="profile">
      <header className="Main">
        <div className="nav_left">
          <div className="logo" onClick={() => navigate('/Main')}>
            <p>DesignQuery</p>
          </div>
          <nav>
            <div className={`folder ${activeFolder === 'users' ? 'active' : ''}`} onClick={() => setActiveFolder('users')}>
              <a href="/Users" className="nav_item">Users</a>
            </div>
            <div className={`folder ${activeFolder === 'admin' ? 'active' : ''}`} onClick={() => setActiveFolder('admin')}>
              <a href="/AdminPanel" className="nav_item">Admin Panel</a>
            </div>
          </nav>
        </div>
        <div className="nav_right">
          <div onClick={() => setUserProfileVisible(!userProfileVisible)} className="user_info">
            <div className="user_inform">
              <p><strong>{userData ? userData.role : 'Loading...'}</strong></p>
              <span className="user_name">{userData ? userData.fullName : 'Guest'}</span>
            </div>
            <img src={userProfileImage} alt="Profile" className="user_image" />
          </div>
          {userProfileVisible && (
            <div className="dropdown_menu">
              <button className="dropdown_item" onClick={() => navigate('/Profile')}>My Profile</button>
              <button className="dropdown_item" onClick={handleLogout}>Log out</button>
            </div>
          )}
        </div>
      </header>

      <div className="profile_container">
  {userData && (
    <div className="profile_card">
      <h2>User Profile</h2>
      {editing ? (
        <form onSubmit={handleFormSubmit}>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleInputChange}
            placeholder="Full Name"
          />
          <input
            type="text"
            name="login"
            value={formData.login}
            onChange={handleInputChange}
            placeholder="Login"
          />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Email"
          />
          <input type="file" name="profilePicture" onChange={handleImageChange} />
          <button type="submit" className="button">Save</button>
        </form>
      ) : (
        <div className="info_list_container">
          <div className="info_column">
            <p><strong>Full Name:</strong></p>
            <p><strong>Login:</strong></p>
            <p><strong>Email:</strong></p>
            <p><strong>Role:</strong></p>
            <p><strong>Rate:</strong></p>
          </div>
          <div className="info_column">
            <p>{userData.fullName || 'None'}</p>
            <p>{userData.login || 'None'}</p>
            <p>{userData.email || 'None'}</p>
            <p>{userData.role || 'USER'}</p>
            <p>{userData.rate || '0'}</p>
          </div>
        </div>
      )}


              {!editing && <button onClick={handleEditToggle} className='button'>Edit Profile</button>}
            </div>
          )}
              {/* New Post (for all users) */}
              <div className="create_post_card">
                <h2>Create New Post</h2>
                <form onSubmit={handleCreatePost}>
                <input
                  type="text"
                  name="title"
                  value={newPostData.title}
                  onChange={handleNewPostChange}
                  placeholder="Title"
                />
                <textarea
                  name="content"
                  value={newPostData.content}
                  onChange={handleNewPostChange}
                  placeholder="Content"
                />
                
                <div className="select_category_container">
  <div className="select_category">
    <button
      type="button"
      onClick={toggleSelectCategoryDropdown}
      className="select_category_button"
    >
      <span>Select Categories</span>
      <img
        src={`/icons/${isSelectCategoryDropdownVisible ? 'hide-categories.svg' : 'show-categories.svg'}`}
        alt="Toggle categories"
      />
    </button>
    {isSelectCategoryDropdownVisible && (
      <div className="select_categories_dropdown">
        {categories.map((category) => (
          <div key={category.id} className="category_item">
            <input
              className="checkbox"
              type="checkbox"
              id={`category-${category.id}`}
              checked={selectedCategories.includes(category.id)}
              onChange={() => handleSelectCategoryChange(category.id)}
            />
            <label htmlFor={`category-${category.id}`}>{category.title}</label>
          </div>
        ))}
      </div>
    )}
  </div>
</div>


                <button type="submit" className="button">Create Post</button>
              </form>
              </div>

        {/* New Category (for admins only) */}
        {role === 'ADMIN' && (
          <div className="create_category_card">
            <h2>Create New Category</h2>
            <form onSubmit={handleCreateCategory}>
              <input
                type="text"
                name="title"
                value={newCategoryData.title}
                onChange={handleNewCategoryChange}
                placeholder="Category"
              />
              <button type="submit" className="button">Create Category</button>
            </form>
          </div>
        )}
        </div>

      <div className='main_container'>
        <div className='search_and_filter_container'>

            {/* Search bar */}
            <div className="search_bar">
            <div className="search_input">
              <input
                type="text"
                placeholder="Search by title or content"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                style={{ paddingLeft: '60px', width: '100%' }}
                ref={searchRef}
              />
              <img src="/icons/search.svg" alt="Search" />
            </div>
          </div>
          
          {/* Filter by category */}
          <div className="category_filter_container">
            <div className="category_filter">
              <button
                onClick={toggleFilterCategoryDropdown}
                className="filter_button"
              >
                <span>Filter by category</span>
                <img
                  src={`/icons/${isFilterCategoryDropdownVisible ? 'hide-categories.svg' : 'show-categories.svg'}`}
                  alt="Toggle categories"
                />
              </button>
              {isFilterCategoryDropdownVisible && (
                <div className="categories_dropdown">
                  {categories.map((category) => (
                    <div key={category.id} className="category_item">
                      <input
                        className="checkbox"
                        type="checkbox"
                        id={`filter-category-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onChange={() => handleCategorySelection(category.id)}
                      />
                      <label htmlFor={`filter-category-${category.id}`}>{category.title}</label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="main_content">
        {posts.map((post) => (
  <div key={post.id} className="post_container">
    {/* Post Header with User Info */}
    <div className="post_header">
      <div className="post_user_info">
        <img
          src={post.author?.profilePicture || '/icons/default-avatar.png'}
          alt="User profile"
          className="profile_img"
        />
        <p>{post.author?.fullName || 'Unknown User'}</p>
      </div>
      <div className="post_reactions">
        {/* Like Button */}
        <button
          className={`like_button ${likedPosts.has(post.id) ? 'liked' : ''} ${isHovered.like === post.id ? 'hovered' : ''}`}
          onClick={() => handleLikeDislike(post.id, 'LIKE')}
          onMouseEnter={() => setIsHovered({ ...isHovered, like: post.id })}
          onMouseLeave={() => setIsHovered({ ...isHovered, like: null })}
        >
          <img
            src={`/icons/Like on post/${likedPosts.has(post.id) ? 'Liked' : (isHovered.like === post.id ? 'Hover' : 'Default')}.svg`}
            alt="Like"
          />
        </button>
        {/* Dislike Button */}
        <button
          className={`dislike_button ${likedPosts.has(post.id) ? 'disliked' : ''} ${isHovered.dislike === post.id ? 'hovered' : ''}`}
          onClick={() => handleLikeDislike(post.id, 'DISLIKE')}
          onMouseEnter={() => setIsHovered({ ...isHovered, dislike: post.id })}
          onMouseLeave={() => setIsHovered({ ...isHovered, dislike: null })}
        >
          <img
            src={`/icons/Dislike on post/${likedPosts.has(post.id) ? 'Disliked' : (isHovered.dislike === post.id ? 'Hover' : 'Default')}.svg`}
            alt="Dislike"
          />
        </button>
      </div>
    </div>

    {/* Post Content or Editing Form */}
    {editingPost === post.id ? (
      <form onSubmit={(e) => handleSubmitEditPost(e, post.id)} className="edit_post_form">
        <input
          type="text"
          name="title"
          value={newPostData.title}
          onChange={handleNewPostChange}
          placeholder="Title"
        />
        <textarea
          name="content"
          value={newPostData.content}
          onChange={handleNewPostChange}
          placeholder="Content"
        />
        <div className="select_category_container">
          <div className="select_category">
            <button
              type="button"
              onClick={toggleSelectCategoryDropdown}
              className="select_category_button"
            >
              <span>Select Categories</span>
              <img
                src={`/icons/${isSelectCategoryDropdownVisible ? 'hide-categories.svg' : 'show-categories.svg'}`}
                alt="Toggle categories"
              />
            </button>
            {isSelectCategoryDropdownVisible && (
              <div className="select_categories_dropdown">
                {categories.map((category) => (
                  <div key={category.id} className="category_item">
                    <input
                      className="checkbox"
                      type="checkbox"
                      id={`category-${category.id}`}
                      checked={selectedCategories.includes(category.id)}
                      onChange={() => handleCategoryChange(category.id)}
                    />
                    <label htmlFor={`category-${category.id}`}>{category.title}</label>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <button type="submit">Save Post</button>
        <button type="button" onClick={() => setEditingPost(null)}>Cancel</button>
      </form>
    ) : (
      <>
        <h2 className="post_title">{post.title}</h2>
        <p className="post_content">{post.content}</p>
        <p className="post_category">
          <strong>Categories: </strong>
          {post.categories && post.categories.length > 0
            ? post.categories.map((category) => category.title).join(' | ')
            : 'No category'}
        </p>
        {/* Edit and Delete Buttons */}
        <div className="post_actions">
          <button onClick={() => handleEditPost(post)} className="edit_post_button">Edit</button>
          <button onClick={() => handleDeletePost(post.id)} className="delete_post_button">Delete</button>
        </div>
      </>
    )}

    {/* Comments Section */}
    <div className="comments_section">
      <button
        onClick={() => toggleComments(post.id)}
        className="comment_toggle_button"
      >
        <span>Comments</span>
        {commentsVisible[post.id] ? (
          <img src="/icons/hide-comments-icon.svg" alt="Hide comments" />
        ) : (
          <img src="/icons/show-comments-icon.svg" alt="Show comments" />
        )}
      </button>

      {commentsVisible[post.id] && (
<div className="comments_list">
  {post.comments?.length > 0 ? (
    post.comments.map((comment) => (
      <div key={comment.id} className="comment">
        <div className="comment_author">
          {/* Display avatar and full name */}
          {comment.author?.avatar && (
            <img
              src={comment.author.avatar}
              alt={`${comment.author?.fullName}'s avatar`}
              className="avatar"
            />
          )}
          <strong>{comment.author?.fullName}</strong>
        </div>
        <Comment
          comment={comment}
          onDelete={handleCommentDelete}
          onUpdate={handleCommentUpdate}
        />
        {/* Reply Button */}
        <button
          onClick={() => handleReplyClick(comment)}
          className="reply_button"
        >
          Reply
        </button>

        {/* Render replies for each comment */}
        {comment.replies &&
          comment.replies.map((reply) => (
            <div key={reply.id} className="reply">
              <div className="reply_author">
                {/* Display reply avatar and full name */}
                {reply.author?.avatar && (
                  <img
                    src={reply.author.avatar}
                    alt={`${reply.author?.fullName}'s avatar`}
                    className="avatar"
                  />
                )}
                <strong>{reply.author?.fullName}</strong>
              </div>
              <p>{reply.content}</p>
              <div className="edit_and_delete_container">
                <button
                  onClick={() =>
                    handleReplyDelete(post.id, comment.id, reply.id)
                  }
                >
                  Delete Reply
                </button>
                <button
                  onClick={() =>
                    handleReplyUpdate(
                      post.id,
                      comment.id,
                      reply.id,
                      'Updated content'
                    )
                  }
                >
                  Edit Reply
                </button>
              </div>
            </div>
          ))}
      </div>
    ))
  ) : (
    <p>No comments yet</p>
  )}

  {/* Form to create a new comment */}
  <div className="create_comment">
    {replyingToCommentId ? (
      // Reply to comment input
      <div className="create_reply">
        <textarea
          value={newReplyContent}
          onChange={(e) => setNewReplyContent(e.target.value)}
          placeholder="Write your reply here..."
          className="comment_input"
        />
        <div className="post_comment_actions">
          <button
            onClick={() =>
              handleReplySubmit(post.id, replyingToCommentId, newReplyContent)
            }
            className="submit_comment_button"
          >
            Post reply
          </button>
          <button
            onClick={handleCancelReply} // Cancel the reply
            className="cancel_comment_button"
          >
            Cancel
          </button>
        </div>
      </div>
    ) : (
      // Create new comment input
      <div>
        <textarea
          value={newCommentContent}
          onChange={(e) => setNewCommentContent(e.target.value)}
          placeholder="Write your comment here..."
          className="comment_input"
        />
        <div className="post_comment_actions">
          <button
            onClick={() => handleCommentSubmit(post.id, newCommentContent)}
            className="submit_comment_button"
          >
            Post comment
          </button>
          <button
            onClick={() => setNewCommentContent('')} // Clear input when cancel is clicked
            className="cancel_comment_button"
          >
            Cancel
          </button>
        </div>
      </div>
    )}
  </div>
</div>


      )}
    </div>
  </div>
))}

        </div>
      </div>
    </div>
  );
};

export default Profile;
