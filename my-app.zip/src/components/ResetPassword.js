import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ResetPassword = () => {
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false); // Track submission state
  const navigate = useNavigate();

  // Validate Email
  const validateEmail = (email) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return 'Email is required.';
    if (!emailPattern.test(email)) return 'Enter a valid email address.';
    return '';
  };

  // Handle changes in email input field
  const handleEmailChange = (e) => {
    const newEmail = e.target.value;
    setEmail(newEmail);
    setEmailError(validateEmail(newEmail));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const error = validateEmail(email);
    if (error) {
      setEmailError(error); // Show the error message
      return; // Prevent form submission if validation fails
    }

    setIsSubmitting(true); // Disable the button and show loading state
    
    try {
      // Send a POST request to backend for password reset
      const response = await axios.post('http://localhost:5000/api/auth/password-reset', { email });
      console.log('Password reset request sent:', response.data);
      
      // Display a success message and redirect to SignIn page
      navigate('/SignIn');
    } catch (err) {
      console.error('Error during password reset request:', err.response);
      setEmailError(err.response?.data?.message || 'An error occurred.');
    } finally {
      setIsSubmitting(false); // Enable the button again after completion
    }
  };

  return (
    <div>
      {/* Header Section */}
      <header className="header_sign_in">
        <p className="logo">DesignQuery</p>
      </header>

      {/* Reset Password Section */}
      <main>
        <div className="sign_up">
          {/* Overlay Text */}
          <div className="overlay_text">
            <div className="infotext">
              <h1>Hello, Friend!</h1>
              <p>Enter your personal details and start your journey with us.</p>
            </div>
            {/* Redirect to SignIn page */}
            <button type="button" className="sign_in_button" onClick={() => navigate('/SignIn')}>
              Sign in
            </button>
          </div>

          {/* Form Container */}
          <div className="form_container" id="sign_up_form">
            <h1>Reset Password</h1>
            <form onSubmit={handleSubmit} noValidate>
              <div className="container">
                {/* Email Input Field */}
                <div className="input_box">
                  <label htmlFor="email">
                    Email<span className="required"> *</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={handleEmailChange}
                    required
                  />
                  {emailError && <small id="emailError" className="error">{emailError}</small>}
                </div>

                {/* Submit Button */}
                <button type="submit" className="button" disabled={isSubmitting}>
                  {isSubmitting ? 'Sending...' : 'Reset Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ResetPassword;
