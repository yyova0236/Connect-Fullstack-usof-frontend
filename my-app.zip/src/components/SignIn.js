import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import axios from 'axios';  // Import axios for API requests

const SignIn = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState({});
  const [loginError, setLoginError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  // Validation functions
  const validateEmail = (email) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) return 'Email is required.';
    if (!emailPattern.test(email)) return 'Enter a valid email address.';
    return '';
  };

  const validatePassword = (password) => {
    if (!password) return 'Password is required.';
    if (password.length < 8) return 'Password must be at least 8 characters long.';
    return '';
  };

  // Handle changes to form fields with validation
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });

    // Validate field on input change
    if (name === 'email') {
      setErrors((prevErrors) => ({
        ...prevErrors,
        email: validateEmail(value),
      }));
    } else if (name === 'password') {
      setErrors((prevErrors) => ({
        ...prevErrors,
        password: validatePassword(value),
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = {
      email: validateEmail(formData.email),
      password: validatePassword(formData.password),
    };

    setErrors(validationErrors);

    if (Object.values(validationErrors).some((error) => error)) return;

    setIsSubmitting(true);

    try {
      const response = await axios.post('/api/auth/login', formData);
      
      const { token, userId, role } = response.data;

      localStorage.setItem('token', token);
      localStorage.setItem('userId', userId);
      localStorage.setItem('role', role);

      setLoginError('');
      console.log('User logged in successfully');
      
      navigate('/Main'); 
    } catch (err) {
      console.error('Login error:', err.response);
      setLoginError(err.response?.data?.error || 'An error occurred. Please try again.');
    }

    setIsSubmitting(false); // Set submission state to false after completion
};

  return (
    <div>
      {/* Header Section */}
      <header className="header">
        <p className="logo">DesignQuery</p>
      </header>

      {/* Sign In Form Section */}
      <div className="sign_in">
        <div className="overlay_text">
          <div className="infotext">
            <h1>Hello, Friend!</h1>
            <p>Enter your personal details and start your journey with us.</p>
          </div>
          {/* Redirect to SignUp page on button click */}
          <button type="button" className="sign_up_button" onClick={() => navigate('/SignUp')}>
            Create Account
          </button>
        </div>

        <div className="form_container">
          <h1>Sign in</h1>
          <form id="LoginForm" onSubmit={handleSubmit} noValidate>
            <div className="container">
              {/* Email Field */}
              <div className="input_box">
                <label htmlFor="email">Email<span className="required"> *</span></label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                {errors.email && <small className="error">{errors.email}</small>}
              </div>

              {/* Password Field */}
              <div className="input_box">
                <label htmlFor="password">Password<span className="required"> *</span></label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                {errors.password && <small className="error">{errors.password}</small>}
              </div>

              {/* Login Error */}
              {loginError && <small className="error">{loginError}</small>}

              {/* Forgot Password Link */}
              <div className="forgot_pass_box">
                <span
                  className="link"
                  onClick={() => navigate('/ResetPassword')}
                >
                  Forgot your password?
                </span>
              </div>

              {/* Submit Button */}
              <button 
                type="submit" 
                className="button" 
                disabled={isSubmitting} // Disable button while submitting
              >
                {isSubmitting ? 'Signing In...' : 'Sign in'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignIn;