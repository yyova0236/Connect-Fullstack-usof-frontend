import React, { useState } from 'react';
import axios from 'axios';

const TestConnection = () => {
  const [connectionStatus, setConnectionStatus] = useState(null);

  const checkConnection = async () => {
    try {
      const response = await axios.get('/api/test'); // Adjust the endpoint if necessary
      if (response.status === 200) {
        setConnectionStatus('Backend is connected!');
      } else {
        setConnectionStatus('Backend responded but with an issue.');
      }
    } catch (error) {
      setConnectionStatus('Failed to connect to the backend.');
      console.error('Error:', error);
    }
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Test Backend Connection</h1>
      <button onClick={checkConnection} style={{ padding: '10px 20px', fontSize: '16px' }}>
        Test Connection
      </button>
      {connectionStatus && <p style={{ marginTop: '20px', fontSize: '18px' }}>{connectionStatus}</p>}
    </div>
  );
};

export default TestConnection;
