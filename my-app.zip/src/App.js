import React, { useRef } from 'react';
import axios from 'axios';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import './App.css';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import ResetPassword from './components/ResetPassword';
import Main from './components/Main';
import Profile from './components/Profile';
import Users from './components/Users';
import AdminPanel from './components/AdminPanel';

axios.defaults.baseURL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000';
axios.defaults.headers.common['Content-Type'] = 'application/json';

const App = () => {
  const location = useLocation();
  const nodeRef = useRef(null);

  return (
    <TransitionGroup>
      <CSSTransition
        key={location.key}
        in={true}
        appear={true}
        classNames="fade"
        timeout={300}
        nodeRef={nodeRef}
      >
        <div ref={nodeRef}>
          <Routes location={location}>
            <Route path="/" element={<SignUp />} />
            <Route path="/SignIn" element={<SignIn />} />
            <Route path="/SignUp" element={<SignUp />} />
            <Route path="/Main" element={<Main />} />
            <Route path="/Profile" element={<Profile />} />
            <Route path="/ResetPassword" element={<ResetPassword />} />
            <Route path="/Users" element={<Users />} />
            <Route path="/AdminPanel" element={<AdminPanel />} />
          </Routes>
        </div>
      </CSSTransition>
    </TransitionGroup>
  );
};

const WrappedApp = () => (
  <Router>
    <App />
  </Router>
);

export default WrappedApp;
